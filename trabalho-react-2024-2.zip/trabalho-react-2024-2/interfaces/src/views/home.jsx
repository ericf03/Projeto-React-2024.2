import { AntDesign } from '@expo/vector-icons'
import React from 'react'
import { Dimensions, Image, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import data from '../data/data'

function Home({ onLogout }) {
	const { width, height } = Dimensions.get('screen')
	const estilos = StyleSheet.create({
		container: {
			flex: 1,
			justifyContent: 'center',
			alignItems: 'center',
      backgroundColor:'#5c5de5',
		},
		button: {
			justifyContent: 'center',
			alignItems: 'center',
			gap: 8,
			borderRadius: 100,
			borderWidth: 1,
			marginHorizontal: 2,
			backgroundColor:'#5c5de5',
      padding:15,
      borderColor:'white',
		},
		inputContainer: {
			flexDirection: 'row',
		},
		input: {
			borderWidth: 1,
			borderRadius: 4,
			padding: 8,
			margin: 8,
			flex: 1,
      borderColor:'gray',
      backgroundColor:'white',
		},
		inputButton: {
			justifyContent: 'center',
			alignItems: 'center',
			marginRight: 8,
		},
		itensContainer: {
			flexDirection: 'row',
			gap: 8,
			margin: 8,
		},
		imagem: {
			height: 80,
			width: 160,
		},
	})
	return (
		<SafeAreaView style={estilos.container}>
			<View style={{ height: 50, justifyContent: 'center', padding: 4, width: width }}>
			</View>
			<View style={estilos.container}>
				<View style={estilos.inputContainer}>
					<TouchableOpacity activeOpacity={0.6} style={estilos.button} onPress={() => onLogout(false)}>
						<AntDesign name='dingding' size={40} color='white' />
						<Text style={{fontSize:20, color:'white'}}>Sair</Text>
					</TouchableOpacity>
					<TextInput style={estilos.input} />
					<TouchableOpacity style={estilos.inputButton}>
						<AntDesign name='search1' size={24} color='white' />
					</TouchableOpacity>
				</View>
				<ScrollView>
					{data.map((el, ix) => (
						<View style={estilos.itensContainer} key={ix}>
							<Image source={el.imagem} style={estilos.imagem} />
							<View>
								<Text>{el.nome}</Text>
								<Text>{el.valor}</Text>
							</View>
						</View>
					))}
				</ScrollView>
			</View>
		</SafeAreaView>
	)
}

export default Home