import { AntDesign } from '@expo/vector-icons'
import React from 'react'
import { Dimensions, Image, StyleSheet,TextInput, Text, TouchableOpacity, onPressHandler, View  } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import guest from '../../assets/login-native.png'

function Login({ onLogin }) {
	const { width, height } = Dimensions.get('screen')
	const estilos = StyleSheet.create({
		container: {
			flex: 1,
			justifyContent: 'center',
			alignItems: 'center',
      backgroundColor:'#5c5de5',
		},
		imagem: {
			height: 200,
			width: 200,
		},
		text: {
			marginLeft: width-100,
			width: width - 16,
			fontSize: 30,
			marginTop: 4,
      color:'white'
		},
		input: {
			borderWidth: 1,
			borderRadius: 4,
			padding: 8,
			margin: 8,
			width: width - 35,
      borderColor:'white',
      backgroundColor:'white',
		},
		button: {
		  padding:20,
			borderWidth: 5,
			borderRadius: 4,
      borderColor:'magenta',
      backgroundColor:'#5c5de5',
      borderRadius:50,
      elevation:5,
      flexDirection:'row',
      gap:15,
      alignItems:'center'
		},
	})

	return (
		<SafeAreaView style={estilos.container}>
			<Image source={guest} style={estilos.imagem} />
			<Text style={estilos.text}>Login</Text>
			<TextInput style={estilos.input} />
			<Text style={estilos.text}>Senha</Text>
			<TextInput style={estilos.input} />
      <TouchableOpacity activeOpacity={0.6} onPress={onPressHandler} onPress={() => onLogin(true)}>
        <View style={estilos.button}>
          <Text style={{fontSize:20, color:'white'}}>Acessar</Text>
				  <AntDesign name='medicinebox' size={30} color='white' />
          
        </View>
      </TouchableOpacity>
      
		</SafeAreaView>
	)
}

export default Login